<?php get_header(); ?>

<section style="padding:50px;">
<h1>FIFA World Cup 2026</h1>

<p>Live Matches</p>

<div style="background:#111;padding:20px;margin:10px;">
Argentina vs Brazil
</div>

<div style="background:#111;padding:20px;margin:10px;">
France vs Spain
</div>

</section>

<?php get_footer(); ?>