<footer style="text-align:center;padding:30px;background:#111;">
© 2026 SuptoTV FIFA
</footer>

<?php wp_footer(); ?>
</body>
</html>