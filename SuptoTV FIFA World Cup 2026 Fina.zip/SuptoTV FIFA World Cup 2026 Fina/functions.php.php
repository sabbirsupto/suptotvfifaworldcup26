<?php

function suptotv_assets(){
wp_enqueue_style('main', get_template_directory_uri().'/assets/css/main.css');
wp_enqueue_script('main', get_template_directory_uri().'/assets/js/main.js', [], null, true);
}
add_action('wp_enqueue_scripts','suptotv_assets');