<!DOCTYPE html>
<html>
<head>
<title>SuptoTV FIFA 2026</title>
<?php wp_head(); ?>
</head>
<body>

<h2 style="padding:20px;">SuptoTV FIFA World Cup 2026</h2>