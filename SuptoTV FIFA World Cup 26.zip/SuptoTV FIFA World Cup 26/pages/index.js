import Sidebar from "../components/Sidebar";
import Card from "../components/Card";
import { matches, standings } from "../data/matches";

export default function Home() {
  return (
    <div className="container">
      <Sidebar />

      <div className="main">
        <h1>🏆 FIFA World Cup 2026</h1>

        <Card title="🔴 Live Matches" items={matches} />
        <Card title="📊 Standings" items={standings} />
      </div>
    </div>
  );
}