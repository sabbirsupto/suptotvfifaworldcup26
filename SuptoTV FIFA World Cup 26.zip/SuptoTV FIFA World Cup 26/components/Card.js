export default function Card({ title, items }) {
  return (
    <div className="card">
      <h3>{title}</h3>
      {items.map((item, i) => (
        <div className="item" key={i}>
          ⚽ {item}
        </div>
      ))}
    </div>
  );
}