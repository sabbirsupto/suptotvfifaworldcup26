export default function Sidebar() {
  return (
    <div className="sidebar">
      <h2>⚽ FIFA26BD</h2>
      <a href="#">Dashboard</a>
      <a href="#">Matches</a>
      <a href="#">Teams</a>
      <a href="#">Standings</a>
    </div>
  );
}