const matchBox = document.getElementById("matches");
const standBox = document.getElementById("standings");
const aiBox = document.getElementById("ai");

/* Matches */
matches.forEach(m=>{
  let div = document.createElement("div");
  div.className = "item";
  div.innerHTML = "⚽ " + m;
  matchBox.appendChild(div);
});

/* Standings */
standings.forEach(s=>{
  let div = document.createElement("div");
  div.className = "item";
  div.innerHTML = "📊 " + s;
  standBox.appendChild(div);
});

/* AI */
aiInsights.forEach(a=>{
  let div = document.createElement("div");
  div.className = "item";
  div.innerHTML = "🤖 " + a;
  aiBox.appendChild(div);
});