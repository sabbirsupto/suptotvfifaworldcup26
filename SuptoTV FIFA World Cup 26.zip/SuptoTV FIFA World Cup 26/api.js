async function fetchLiveData(){
  // future: football API connect here
  return "Live data system ready 🚀";
}