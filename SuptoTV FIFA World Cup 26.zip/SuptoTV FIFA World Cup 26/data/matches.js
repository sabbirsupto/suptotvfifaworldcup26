export const matches = [
  "Argentina vs Brazil - LIVE",
  "France vs Spain - UPCOMING",
  "England vs Germany - FINISHED"
];

export const standings = [
  "1. Argentina - 9 pts",
  "2. Brazil - 6 pts",
  "3. France - 4 pts",
  "4. Spain - 3 pts"
];